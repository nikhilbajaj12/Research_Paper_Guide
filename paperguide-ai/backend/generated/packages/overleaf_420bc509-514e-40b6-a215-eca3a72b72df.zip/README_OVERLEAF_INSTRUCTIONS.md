# README: Overleaf LaTeX Package - Conference

## Setup

1. **Create New Project**:
   - Go to Overleaf.com
   - Create new project from uploaded ZIP

2. **Verify Template**:
   - Ensure `default_2026.sty` exists in project root
   - If missing, upload the official style file manually

3. **Set Main File**:
   - In Overleaf menu, set `main.tex` as main file

4. **Add References**:
   - Edit `references.bib` with your BibTeX entries
   - Delete TODO examples
   - Do NOT leave empty `references.bib` if using citations

## Compilation

1. Recompile from scratch if references do not appear:
   - Delete auxiliary files: `.aux`, `.bbl`, `.log`
   - Recompile main.tex

2. If compilation fails:
   - Check `main.tex` for syntax errors
   - Verify all `\cite{}` commands have matching entries in `references.bib`
   - Check character encoding (UTF-8)

## Conference Requirements

- **Conference**: Conference
- **Page Limit**: N/A pages
- **Reference Style**: bibtex
- **Blind Review**: Yes

## Compliance Summary

- **Score**: 68/100
- **Status**: major_fixes
- **Critical Issues**: 0
- **Warnings**: 4

See `compliance_report.json` and `recommendations.md` for full details.

## Compliance Checklist

Before submission, verify:

1. **Page Limit**: Confirm page count does not exceed N/A pages
2. **References**: All citations have corresponding BibTeX entries
3. **Citations**: All `\cite{}` commands are present for referenced work
4. **Anonymity**: No author names, emails, or identifying information (unless preprint)
5. **Checklist**: Include required conference submission checklist if needed
6. **Template**: Using official default_2026 style

## TODO Tasks

Check main.tex for TODO comments:
- [ ] Add introduction
- [ ] Add related work
- [ ] Add method description
- [ ] Add experimental setup
- [ ] Add results
- [ ] Add discussion
- [ ] Add conclusion
- [ ] Verify all claims are supported by citations
- [ ] Fill in references.bib

## Support

- Official Template: https://default.cc/
- Overleaf Help: https://www.overleaf.com/help

For compliance questions:
- Review `compliance_report.json` for detailed checklist
- Review `recommendations.md` for actionable fixes
